import { Quiz } from './quiz.model';

describe('Quiz', () => {
  it('should create an instance', () => {
    expect(new Quiz()).toBeTruthy();
  });
});
