import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { QuestionsService } from '../questions.service';
import { Answers, Choice, Question } from '../quiz.model';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.scss']
})
export class QuestionsComponent implements OnInit {
  title = 'Quiz Application'
  answers: Answers;
  questions: Question[];
  randomQueItems: Question[];
  currentQuestionIndex: number;

  showResults = false;
  randomQuestion: Question;
  // inject both the active route and the questions service
  constructor(private route: ActivatedRoute, private questionsService: QuestionsService) { }

  ngOnInit() {
    //read from the dynamic route and load the proper quiz data
    this.questionsService.getQuestions()
      .subscribe(questions => {
        this.currentQuestionIndex = 0;
        this.questions = questions;  
        this.randomQueItems = this.randomQuestions(this.questions).slice(0, 5); // this is provided you want 5 numbers.
        console.log(this.randomQueItems);       
        this.answers = new Answers();
      });
  }

  randomQuestions(a) {
    var j, x, i;
    for (i = a.length - 1; i > 0; i--) {
      j = Math.floor(Math.random() * (i + 1));
      x = a[i];
      a[i] = a[j];
      a[j] = x;
    }
    return a;
  }

  updateChoice(choice: Choice) {
    this.answers.values[this.currentQuestionIndex] = choice;
  }

  nextOrViewResults() {
    if (this.currentQuestionIndex === this.randomQueItems.length - 1) {
      this.showResults = true;
      return;
    }
    this.currentQuestionIndex++;
  }

  reset() {
    this.questions = undefined;
    this.answers = undefined;
    this.currentQuestionIndex = undefined;
  }

}
