import { Component, Input } from '@angular/core';
import { Answers, Question } from '../quiz.model';
import { ChartType, ChartOptions } from 'chart.js';
import { SingleDataSet, Label, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from 'ng2-charts';


@Component({
  selector: 'app-results',
  templateUrl: './results.component.html',
  styleUrls: ['./results.component.scss']
})
export class ResultsComponent {
  // used to make answers available to parent component (= questions)
  // so that parent can pass it to child component (= results)
  @Input() answers: Answers;
  @Input() questions: Question[];

  // Pie
  public pieChartOptions: ChartOptions = {
    responsive: true,
  };
  public pieChartLabels: Label[] = ['Wrong Answers', 'Correct Answers'];
  public pieChartData: SingleDataSet = [];
  public pieChartType: ChartType = 'pie';
  public pieChartLegend = true;
  public pieChartPlugins = [];

  constructor() {
    monkeyPatchChartJsTooltip();
    monkeyPatchChartJsLegend();
  }

  ngOnInit() {
    console.log('ansers', this.answers);
    let correctAnswersCount = this.answers.values.filter(item => item.correct == true).length;
    let wrongAnswersCount = this.answers.values.filter(item => item.correct == false).length;
    this.pieChartData[0] = wrongAnswersCount;
    this.pieChartData[1] = correctAnswersCount;
  }

}