//define, what'll be used later on
import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Question } from './quiz.model';

@Injectable({
  providedIn: 'root'
})
export class QuestionsService {

  constructor(private http: HttpClient) {
   }
  public getQuestions() {
    return this.http.get(`./assets/generalQuestions.json`).pipe(
      map((result: any[]) => {
        return result.map(r => new Question(r.label, r.choices, r.questionIndex));
      })
    );
  }
}
 